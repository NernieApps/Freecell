import 'package:flutter/material.dart';

void main() => runApp(FreecellApp());

class FreecellApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Freecell',
      home: Scaffold(
        appBar: AppBar(title: Text('Freecell')),
        body: Center(child: Text('Freecell Engine Placeholder')),
      ),
    );
  }
}
